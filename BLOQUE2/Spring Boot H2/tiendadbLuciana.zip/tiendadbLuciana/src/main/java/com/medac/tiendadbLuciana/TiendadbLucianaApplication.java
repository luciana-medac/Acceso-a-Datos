package com.medac.tiendadbLuciana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendadbLucianaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendadbLucianaApplication.class, args);
	}

}
