package com.example.demo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import jakarta.persistence.Query;

public class GestionRestauranteApplication {

	public static void main(String[] args) {

		SessionFactory SessionFactory = new Configuration().configure().buildSessionFactory();
		Session session;

		try {

			Scanner sc = new Scanner(System.in);
			int opcion = 0;

			while (opcion != 12) {

				System.out.println("============ RESERVAS RESTAURANTE ==============");
				System.out.println("1. Crear un restaurante");
				System.out.println("2. Crear Mesa");
				System.out.println("3. Crear un cliente");
				System.out.println("4. Crear una reserva");
				System.out.println("5. Crear un servicio extra");
				System.out.println("6. Asignar servicios a la reserva");
				System.out.println("7. Cambiar fecha de Reserva");
				System.out.println("8. Eliminar un servicio extra de una reserva");
				System.out.println("9. Listar Reservas de un cliente");
				System.out.println("10. Listar todas las reservas de un cliente");
				System.out.println("11. Estadisticas: cantidad de reservas por cliente");
				System.out.println("12. Salir");
				System.out.print("Elige una opción: ");
				opcion = Integer.parseInt(sc.nextLine());

				switch (opcion) {
					case 1:
						// Crear el restaurante
						session = SessionFactory.openSession();
						session.beginTransaction();

						System.out.println("Introduce el nombre del Restaurante: ");
						String nRestaurante = sc.nextLine();

						Restaurante r1 = new Restaurante(nRestaurante);
						session.persist(r1);
						session.getTransaction().commit();
						session.close();

						System.out.println("Se ha añadido correctamente el restaurante: " + nRestaurante);

						break;
					case 2:
						// Crear mesas

						String opcion2 = "";

						do {

							session = SessionFactory.openSession();
							session.beginTransaction();

							System.out.println("Introduce el número de la mesa");
							int numMesa = Integer.parseInt(sc.nextLine());

							System.out.println("Introduce el ID del Restaurante: ");
							int idRestaurante = Integer.parseInt(sc.nextLine());

							Restaurante r = session.get(Restaurante.class, idRestaurante);

							Mesa m1 = new Mesa();

							m1.setNumMesa(numMesa);
							m1.setIdRestaurante(r);

							if (r == null) {
								System.out.println("El Restaurante con ID: " + idRestaurante + " no existe");

							} else {
								System.out.println("Se ha creado correctamente la mesa");
							}

							System.out.println("¿Quieres añadir más mesas?s/n");
							opcion2 = sc.nextLine();

							session.persist(m1);
							session.getTransaction().commit();
							session.close();

						} while (!opcion2.equals("n"));

						break;
					case 3:
						// Crear un cliente
						session = SessionFactory.openSession();
						session.beginTransaction();

						System.out.println("Introduce el nombre del cliente: ");
						String nCliente = sc.nextLine();

						System.out.println("Introduce el teléfono del cliente: ");
						double tCliente = Double.parseDouble(sc.nextLine());

						Cliente c1 = new Cliente(nCliente, tCliente);
						session.persist(c1);
						session.getTransaction().commit();
						session.close();

						System.out.println("Se ha añadido correctamente el cliente");

						break;
					case 4:
						// Crear una reserva
						session = SessionFactory.openSession();
						session.beginTransaction();

						System.out.println("Introduce el ID de la Mesa:");
						int idMesa = Integer.parseInt(sc.nextLine());

						System.out.println("Introduce el ID del Cliente: ");
						int idClienteR = Integer.parseInt(sc.nextLine());

						Mesa m = session.get(Mesa.class, idMesa);
						Cliente c = session.get(Cliente.class, idClienteR);

						Reserva R1 = new Reserva();

						System.out.println("Introduce el día: ");

						System.out.println("Introduce la fecha (dd/MM/yyyy): ");
						String fechaTexto = sc.nextLine();

						SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
						Date fechaR = sdf.parse(fechaTexto);

						R1.setIdCliente(c);
						R1.setIdMesa(m);
						R1.setFecha(fechaR);

						session.persist(R1);
						session.getTransaction().commit();
						session.close();

						if (m == null || c == null) {

							System.out.println("No se ha podido crear la reserva");

						} else {
							System.out.println("Se ha añadido correctamente la reserva");
						}

						break;
					case 5:
						// Crear un servicio extra
						String opcion3 = "";

						do {

							session = SessionFactory.openSession();
							session.beginTransaction();

							System.out.println("Introduce el nombre del servicio:");
							String nServicio = sc.nextLine();

							ServicioExtra s1 = new ServicioExtra(nServicio);

							session.persist(s1);
							session.getTransaction().commit();
							session.close();

							System.out.println("El servicio se ha encontrado correctamente");

							System.out.println("¿Quieres seguir creando servicios? s/n");
							opcion3 = sc.nextLine();

						} while (!opcion3.equals("n"));

						break;
					case 6:
						// Asignar servicios a la reserva

						String seguir = "";
						do {
							session = SessionFactory.openSession();
							session.beginTransaction();

							System.out.println("Introduce el ID de la reserva:");
							int idRes = Integer.parseInt(sc.nextLine());

							Reserva reserva = session.get(Reserva.class, idRes);

							if (reserva == null) {
								System.out.println("No existe la reserva con ID: " + idRes);
								session.close();
								break;
							}

							System.out.println("Introduce el ID del servicio extra que deseas añadir:");
							int idServ = Integer.parseInt(sc.nextLine());

							ServicioExtra serv = session.get(ServicioExtra.class, idServ);

							if (serv == null) {
								System.out.println("No existe el servicio con ID: " + idServ);
							} else {
								
								reserva.getServiciosExtras().add(serv);

								System.out.println("Servicio añadido correctamente.");
							}

							System.out.println("¿Deseas asignar otro servicio? (s/n)");
							seguir = sc.nextLine();

							session.persist(reserva);
							session.getTransaction().commit();
							session.close();

						} while (!seguir.equalsIgnoreCase("n"));

						break;

					case 7:
						// Cambiar la fecha de la Reserva
						session = SessionFactory.openSession();
						session.beginTransaction();

						try {
							System.out.println("Introduce el ID de la reserva: ");
							int IDRes = Integer.parseInt(sc.nextLine());

							System.out.println("Introduce la nueva fecha (dd/MM/yyyy): ");
							String fechaNueva = sc.nextLine();

							SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
							Date fechaRN = sdf1.parse(fechaNueva);

							Query q = session.createQuery(
									"UPDATE Reserva set fecha=:fecha where id=:id");

							q.setParameter("fecha", fechaRN);
							q.setParameter("id", IDRes);

							int actualizadas = q.executeUpdate();

							if (actualizadas == 0) {
								System.out.println("No existe la reserva con ese ID.");
							} else {
								System.out.println("Fecha actualizada correctamente.");
							}

							session.getTransaction().commit();

						} catch (Exception e) {
							System.out.println("Error al actualizar la fecha: " + e.getMessage());
							session.getTransaction().rollback(); // hacemos el rollback aquí porque modifica la base de
																	// datos
						} finally {
							session.close();
						}
						break;
					case 8:
						session = SessionFactory.openSession();
						session.beginTransaction();

						try {
							System.out.println("Introduce el ID de la reserva:");
							int idReserva = Integer.parseInt(sc.nextLine());

							Reserva reserva = session.get(Reserva.class, idReserva);

							if (reserva == null) {
								System.out.println("No existe la reserva con ID: " + idReserva);
								session.close();
								break;
							}

							System.out.println("Introduce el ID del servicio extra que quieres eliminar:");
							int idServEliminar = Integer.parseInt(sc.nextLine());

							ServicioExtra serv = session.get(ServicioExtra.class, idServEliminar);

							if (serv == null) {
								System.out.println("No existe el servicio con ID: " + idServEliminar);
								session.close();
								break;
							}

							// Intentar eliminarlo de la lista
							if (reserva.getServiciosExtras().contains(serv)) {

								reserva.getServiciosExtras().remove(serv);

								System.out.println("Servicio eliminado correctamente de la reserva.");
							} else {
								System.out.println("La reserva NO tiene asociado ese servicio.");
							}

							session.getTransaction().commit();

						} catch (Exception ex) {
							session.getTransaction().rollback();
							System.out.println("Error al eliminar el servicio: " + ex.getMessage());
						} finally {
							session.close();
						}

						break;

					case 9:
						// Lista las Reservas de un cliente y los servicios extra
						session = SessionFactory.openSession();
						session.beginTransaction();

						System.out.println("Introduce el ID del cliente: ");
						int idCli = Integer.parseInt(sc.nextLine());

						List<Reserva> reservasCliente = session.createQuery(
								"FROM Reserva r WHERE r.idCliente.id = :idCliente ORDER BY r.fecha DESC",
								Reserva.class)
								.setParameter("idCliente", idCli)
								.getResultList();

						if (reservasCliente.isEmpty()) {
							System.out.println("Este cliente no tiene reservas.");
						}

						for (Reserva r : reservasCliente) {

							System.out.println("Reserva ID: " + r.getId());
							System.out.println("Fecha: " + r.getFecha());
							System.out.println("Mesa: " + r.getIdMesa().getNumMesa());
							System.out.println("Cliente: " + r.getIdCliente().getNombre());
							System.out.println("Servicios extra asignados:");

							// Mostrar los servicios extra
							if (r.getServiciosExtras().isEmpty()) {
								System.out.println("   (Sin servicios extra)");
							} else {
								for (ServicioExtra s : r.getServiciosExtras()) {
									System.out.println("   - " + s.getNombre());
								}
							}
						}

						session.getTransaction().commit();
						session.close();

						break;

					case 10:

						// Lista todas las reservas de un cliente ordenadas por fecha
						session = SessionFactory.openSession();
						session.beginTransaction();

						System.out.println("Introduce el ID del cliente: ");
						int idClie = Integer.parseInt(sc.nextLine());

						List<Reserva> reservas = session.createQuery(
								"FROM Reserva r WHERE r.idCliente.id = :idCliente ORDER BY r.fecha DESC",
								Reserva.class)
								.setParameter("idCliente", idClie)
								.getResultList();

						for (Reserva r : reservas) {
							System.out.println(
									"Reserva " + r.getId() +
											" - Cliente: " + r.getIdCliente().getNombre() +
											" - Fecha: " + r.getFecha());
						}

						session.getTransaction().commit();
						session.close();

						break;

					case 11:

						// Hace una estadísticas de reservas por ejemplo: Ramon castro tiene 1 reserva,
						// etc.
						session = SessionFactory.openSession();
						session.beginTransaction();

						// Devuelve varios valores por cada fila de resultado
						List<Object[]> resultados = session.createQuery(
								"SELECT r.idCliente.nombre, COUNT(r) " +
										"FROM Reserva r " +
										"GROUP BY r.idCliente.nombre " +
										"ORDER BY COUNT(r) DESC",
								Object[].class).getResultList();

						// De cada fila devuelve un array de Objetos: Cliente y Reserva, entonces la
						// primera posición
						for (Object[] fila : resultados) {
							String nombreCliente = (String) fila[0]; // Corresponde al Cliente (nombre)
							Long totalReservas = (Long) fila[1]; // Corresponde a Reservas (ID Reserva)

							System.out.println(nombreCliente + " tiene " + totalReservas + " reservas");
						}

						session.getTransaction().commit();
						session.close();

						break;

					case 12:

						System.out.println("Programa cerrado");
						break;
					default:

						break;
				}

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
